package com.cmpt276.a3_cookiefinder.model.model.game_obj;

public class Cell {
    boolean revealed;
    boolean hasCookies;
    
}
